# AI Worker Build100 Weakness Map

## Highest Priority

1. Stage4B `CONTACT_PICK` fails.
   - Task: `SS Safe Send Dry-Run`
   - Area: TextNow contact-selection AutoInput route
   - Last known step: `CONTACT_PICK`
   - Safety state: no send task, no send button, `%SSSentOne=0`

2. Send path is not release-proven.
   - Static one-send variables exist.
   - Phone proof for controlled send does not exist yet.
   - Live send must stay blocked.

3. Full dashboard safety is not fully proven.
   - Static click refs resolve.
   - Dangerous/test buttons still need phone proof or explicit hold behavior proof.

## Medium Priority

4. Proof logger clarity.
   - AutoSheets first-write fallback appears handled in some runlogs.
   - ChatGPT should confirm whether any stale proof values still need cleanup.

5. Timer/live path.
   - Timer and live-loop routes exist in XML.
   - They are not allowed until earlier send proof passes.

6. Archive/DeadArchive/Compactor/TT5.
   - Defaults are off or held.
   - Any live use remains unproven.

## Lower Priority After Send Proof

7. 50-contact pressure and backpressure.
   - Cap variables exist:
     - `%AIWMaxActiveContacts=50`
     - `%AIWProcessBatchCapNormal=2`
     - `%AIWProcessBatchCapBacklog=5`
     - `%AIWSendBatchCap=1`
     - `%AIWTickMode=NORMAL`
   - Needs a dedicated phone/runlog pressure proof.

8. Watchdog/recovery.
   - Static watchdog/recovery markers exist.
   - Recovery must prove no send during recovery.

## Forbidden Until Proven

- live-open send
- timer/live loop
- multi-send
- archive live
- deadarchive live
- compactor live
- TT5 live
- any release-ready claim
