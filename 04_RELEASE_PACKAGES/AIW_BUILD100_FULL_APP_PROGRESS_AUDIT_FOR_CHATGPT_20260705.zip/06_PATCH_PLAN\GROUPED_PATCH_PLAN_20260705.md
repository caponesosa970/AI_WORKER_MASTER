# Grouped Patch Plan For Codex

## Current Status

CANDIDATE / HOLD FOR CHATGPT AUDIT AND PATCH ORDER

No more repeated phone tests should run until ChatGPT returns a patch order.

## Group 1: Stage4B CONTACT_PICK Dry-Run Route

Patch only after ChatGPT audits this package.

Allowed scope:

- `SS Safe Send Dry-Run`
- `CONTACT_PICK` area and direct surrounding waits/checks
- proof details for the dry-run pass/fail result

Forbidden:

- real send
- send button
- `FINAL Send Sheet`
- `AIW SEND 1`
- timer/live/autonomous route
- archive/deadarchive/compactor/TT5
- multi-send

Required proof after patch:

- `SS Safe Send Dry-Run = ExitOK`
- `CONTACT_PICK` succeeds
- no `SS Fail UI Dirty Stop`
- `FINAL Send Sheet = 0`
- `AIW SEND 1 = 0`
- `button_send = 0`
- `%SSSentOne=0`

## Group 2: Proof Logging Cleanup

Patch only if ChatGPT says stale/dirty proof values block audit clarity.

Allowed scope:

- set proof error/result/details immediately before proof log calls
- no send/process logic changes

## Group 3: Dashboard Safety Verification

Patch only if ChatGPT finds a button can enter unsafe flow.

Allowed scope:

- labels
- hold checks
- test-button routing

Forbidden:

- changing core send/process behavior unless specifically tied to an unsafe dashboard path

## Group 4: Controlled One-Send Preparation

Only after Stage4B dry-run passes.

Allowed scope:

- one approved test row
- one-send cap verification
- controlled send proof checklist

Forbidden:

- timer/live loop
- multi-send

## Group 5: Timer, Watchdog, Capacity, Archive Gates

Only after controlled one-send passes.

Proof order:

1. timer single-fire proof
2. watchdog/recovery no-send proof
3. 50-contact pressure/backpressure proof
4. archive/deadarchive/compactor proof, if still desired

## Required Static Checks After Any XML Patch

- XML parse
- SHA256
- task/profile/scene counts
- duplicate task IDs
- duplicate task names
- project task refs
- profile task refs
- scene clickTask refs
- Perform Task refs
- Tasker block nesting
- `json:true` count
- `<se>true</se>` count
- mojibake count
- dangerous live path scan
- secret presence check without printing secrets
