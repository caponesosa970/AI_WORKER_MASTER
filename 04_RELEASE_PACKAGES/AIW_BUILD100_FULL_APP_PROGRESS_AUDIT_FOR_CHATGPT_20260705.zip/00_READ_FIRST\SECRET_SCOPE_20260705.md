# Secret Scope

This is the safe/redacted ChatGPT audit package.

## Included

- Redacted controlled XML audit copy
- Static/deep audit reports
- ChatGPT audit results
- Phone proof summaries
- Redacted runlogs
- Patch plan
- SHA256 inventory

## Excluded

- Private WITH_KEY runtime XML
- Private runtime/source packages
- Raw private Stage3A runlogs
- API keys
- plaintext secrets

## Flags

- KEY_PRESENT=true
- KEY_REDACTED_IN_REPORT=true

If ChatGPT needs private files later, create a separate private package. Do not mix it into this safe audit package.
